"""Streamlit frontend for the PDF RAG Lab. Run with: streamlit run app.py"""

import streamlit as st
from rag_engine import PDFRAG, DEFAULT_MODEL_NAME

st.set_page_config(page_title="Free PDF RAG Lab", page_icon="📄", layout="wide")

st.title("📄 PDF RAG Lab")
st.write(
    "Upload a text-based PDF, build a searchable knowledge base, and ask questions "
    "that are answered using passages retrieved from your document."
)
st.caption(
    "Free demo: TF-IDF retrieval + open-source FLAN-T5 Small. "
    "No paid API key is required. First model use downloads model files."
)

with st.expander("What does ‘Build knowledge base’ do?"):
    st.markdown(
        "1. Extract readable text from each PDF page.\n"
        "2. Split text into overlapping chunks and remember page numbers.\n"
        "3. Build a TF-IDF index so relevant chunks can be retrieved for a question.\n\n"
        "This is **RAG indexing**, not fine-tuning or retraining the language model."
    )

if "rag_instance" not in st.session_state:
    st.session_state.rag_instance = None
if "indexed_filename" not in st.session_state:
    st.session_state.indexed_filename = None
if "index_stats" not in st.session_state:
    st.session_state.index_stats = None
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

with st.sidebar:
    st.header("1. Upload a PDF")
    uploaded_pdf = st.file_uploader(
        "Choose a PDF file", type=["pdf"], accept_multiple_files=False
    )
    st.caption("Use a text-based PDF. Scanned image-only PDFs need OCR first.")
    top_k = st.slider("Retrieved passages per question", min_value=1, max_value=5, value=3)
    st.write(f"**Generator:** `{DEFAULT_MODEL_NAME}`")

    build_clicked = st.button(
        "Build / replace knowledge base",
        type="primary",
        use_container_width=True,
        disabled=uploaded_pdf is None,
    )

    if build_clicked and uploaded_pdf is not None:
        try:
            with st.spinner("Reading the PDF and building the index..."):
                rag = PDFRAG()
                stats = rag.build(uploaded_pdf.getvalue(), uploaded_pdf.name)
            st.session_state.rag_instance = rag
            st.session_state.indexed_filename = uploaded_pdf.name
            st.session_state.index_stats = stats
            st.session_state.chat_history = []
            st.success("Knowledge base is ready.")
        except Exception as exc:
            st.error(str(exc))

if st.session_state.index_stats:
    stats = st.session_state.index_stats
    st.subheader("Knowledge base status")
    c1, c2, c3 = st.columns(3)
    c1.metric("PDF", stats["filename"])
    c2.metric("Pages with text", stats["pages_with_text"])
    c3.metric("Chunks indexed", stats["chunks_indexed"])

st.divider()
st.header("2. Ask a question")

if st.session_state.rag_instance is None:
    st.info("Upload a PDF in the sidebar, then click **Build / replace knowledge base**.")
else:
    st.caption(f"Current document: {st.session_state.indexed_filename}")
    with st.form("question_form", clear_on_submit=True):
        question = st.text_input(
            "Your question",
            placeholder="Example: What are the main points discussed in this document?",
        )
        ask_clicked = st.form_submit_button("Ask PDF", type="primary")

    if ask_clicked:
        if not question.strip():
            st.warning("Please type a question first.")
        else:
            try:
                with st.spinner("Retrieving passages and generating an answer..."):
                    result = st.session_state.rag_instance.answer(question, top_k=top_k)
                st.session_state.chat_history.append(
                    {"question": question, "answer": result["answer"], "sources": result["sources"]}
                )
            except Exception as exc:
                st.error(
                    f"Could not answer this question: {exc}\n\n"
                    "On first use, the open-source model must download from Hugging Face. "
                    "Check the app logs if the download or memory allocation fails."
                )

    for item in reversed(st.session_state.chat_history):
        st.markdown("**You asked:** " + item["question"])
        st.markdown("**Answer:** " + item["answer"])
        if item["sources"]:
            with st.expander("Show retrieved PDF passages"):
                for i, source in enumerate(item["sources"], start=1):
                    st.markdown(
                        f"**Passage {i} — PDF page {source['page']}** "
                        f"(retrieval score: {source['score']:.3f})"
                    )
                    st.write(source["text"])
                    if i < len(item["sources"]):
                        st.markdown("---")
        st.divider()

st.caption(
    "Privacy note: this demo does not intentionally save uploaded PDFs to disk, but a hosted app "
    "processes files in its running environment. Do not upload confidential documents to a public demo."
)
