# Free PDF RAG Lab (Python + Streamlit)

A beginner-friendly Retrieval-Augmented Generation (RAG) teaching project. Students upload a PDF, index its text, ask questions, and inspect the retrieved passages and page numbers used as context.

## Features

- PDF text extraction with `pypdf`
- Page-aware overlapping text chunks
- TF-IDF retrieval with scikit-learn (no paid embedding API or vector database)
- Answer generation with `google/flan-t5-small` from Hugging Face
- Streamlit chat interface with inspectable source passages
- No API key and no per-token model API bill

## Important: indexing is not model training

The **Build knowledge base** action extracts, chunks, and indexes the PDF. It does **not** fine-tune or retrain FLAN-T5. This separation is an important RAG concept for the lab.

## Run locally

Recommended: Python 3.11 and a virtual environment.

### Windows (PowerShell)

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

### macOS / Linux

```bash
python3.11 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

The app opens in your browser. The first question that needs generation downloads the model files from Hugging Face, so it needs internet access and can take some time. Later model use is cached while the Python process remains running.

## Deploy from GitHub to Streamlit Community Cloud

1. Create a GitHub repository, for example `free-pdf-rag-lab`.
2. Upload these files to the repository root: `app.py`, `rag_engine.py`, `requirements.txt`, and `README.md`.
3. Commit the files. Do not upload a private PDF or model weights to the public repository.
4. Sign in at <https://share.streamlit.io/> using your GitHub account.
5. Select **Create app** and choose your repository and branch.
6. Set the **Main file path** to `app.py`.
7. Choose Python 3.11 in the app's advanced/settings options if available, then deploy.
8. Wait for the first build and open the app URL. Upload a small, text-based sample PDF to test it.
9. If deployment fails, open **Manage app → Logs**. A model-download or memory error may mean the free hosted instance cannot load the ML dependencies/model reliably. Try locally first or use a smaller/lighter hosting setup.

Official references:
- Streamlit deployment: <https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app/deploy>
- Streamlit dependencies: <https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app/app-dependencies>
- FLAN-T5 Small model card: <https://huggingface.co/google/flan-t5-small>

## Free usage and limitations

- The code calls no paid GPT API and requires no API token.
- `google/flan-t5-small` is open-source (Apache 2.0); model weights are downloaded from Hugging Face on first use.
- There is no honest guarantee of unlimited free hosted usage. Streamlit Community Cloud has CPU, RAM, storage, and usage constraints that can change. The free service can sleep, throttle, or fail if the app exceeds resources.
- The language model is small. It is suitable for a classroom demonstration but may give weaker answers than larger models.
- Text-based PDFs are supported. Scanned/image-only PDFs require OCR, which is not included here.
- TF-IDF is intentionally used as a simple, lightweight retriever to teach RAG fundamentals. It is not a semantic embedding retriever, so it can miss relevant passages when wording differs substantially.
- A hosted public app should not be used for confidential documents.
