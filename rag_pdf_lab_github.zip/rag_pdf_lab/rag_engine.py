"""A small, free-to-run PDF RAG engine for teaching and demonstrations.

This starter uses:
- pypdf for text extraction
- scikit-learn TF-IDF for retrieval (no embedding API or vector database)
- google/flan-t5-small for answer generation (downloaded from Hugging Face)

RAG indexes/retrieves document passages; it does not fine-tune the language model.
"""

from __future__ import annotations

from functools import lru_cache
from io import BytesIO
from typing import Any

from pypdf import PdfReader
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

DEFAULT_MODEL_NAME = "google/flan-t5-small"


@lru_cache(maxsize=2)
def load_generator(model_name: str = DEFAULT_MODEL_NAME):
    """Load and cache a small open-source text-to-text model on CPU/GPU."""
    try:
        import torch
        from transformers import AutoModelForSeq2SeqLM, AutoTokenizer
    except ImportError as exc:
        raise RuntimeError(
            "AI dependencies are missing. Install requirements.txt and try again."
        ) from exc

    try:
        tokenizer = AutoTokenizer.from_pretrained(model_name)
        model = AutoModelForSeq2SeqLM.from_pretrained(model_name)
    except Exception as exc:
        raise RuntimeError(
            f"Could not load '{model_name}'. Check your internet connection and "
            "try again. The model is downloaded from Hugging Face on first use."
        ) from exc

    device = "cuda" if torch.cuda.is_available() else "cpu"
    model.to(device)
    model.eval()
    return tokenizer, model, device


def extract_pdf_pages(pdf_bytes: bytes) -> list[dict[str, Any]]:
    """Extract selectable text from a PDF, keeping original page numbers."""
    if not pdf_bytes:
        raise ValueError("The uploaded PDF is empty.")

    try:
        reader = PdfReader(BytesIO(pdf_bytes))
    except Exception as exc:
        raise ValueError("This file could not be opened as a valid PDF.") from exc

    if reader.is_encrypted:
        try:
            result = reader.decrypt("")
        except Exception as exc:
            raise ValueError("This PDF is password-protected and cannot be read.") from exc
        if not result:
            raise ValueError("This PDF is password-protected and cannot be read.")

    pages: list[dict[str, Any]] = []
    for page_number, page in enumerate(reader.pages, start=1):
        try:
            text = page.extract_text() or ""
        except Exception:
            text = ""
        text = " ".join(text.split())
        if text:
            pages.append({"page": page_number, "text": text})

    if not pages:
        raise ValueError(
            "No selectable text was found. This may be a scanned PDF. "
            "Use a text-based PDF or run OCR before uploading."
        )
    return pages


def split_into_chunks(
    pages: list[dict[str, Any]], chunk_words: int = 180, overlap_words: int = 35
) -> list[dict[str, Any]]:
    """Split each page into word chunks; preserve page numbers for citations."""
    if chunk_words < 20:
        raise ValueError("chunk_words must be at least 20.")
    if overlap_words < 0 or overlap_words >= chunk_words:
        raise ValueError("overlap_words must be >= 0 and smaller than chunk_words.")

    chunks: list[dict[str, Any]] = []
    step = chunk_words - overlap_words
    for page in pages:
        words = page["text"].split()
        for start in range(0, len(words), step):
            piece = " ".join(words[start : start + chunk_words]).strip()
            if piece:
                chunks.append({"page": page["page"], "text": piece})
            if start + chunk_words >= len(words):
                break
    return chunks


class PDFRAG:
    """Build a TF-IDF index from one PDF and answer questions from its passages."""

    def __init__(self, model_name: str = DEFAULT_MODEL_NAME):
        self.model_name = model_name
        self.source_name = "uploaded.pdf"
        self.pages: list[dict[str, Any]] = []
        self.chunks: list[dict[str, Any]] = []
        self.vectorizer: TfidfVectorizer | None = None
        self.matrix = None

    def build(self, pdf_bytes: bytes, source_name: str = "uploaded.pdf") -> dict[str, int | str]:
        """Extract, chunk, and index a PDF. This is indexing, not model training."""
        self.pages = extract_pdf_pages(pdf_bytes)
        self.chunks = split_into_chunks(self.pages)
        if not self.chunks:
            raise ValueError("No text chunks could be created from this PDF.")

        self.vectorizer = TfidfVectorizer(ngram_range=(1, 2), max_features=40_000)
        try:
            self.matrix = self.vectorizer.fit_transform(
                [chunk["text"] for chunk in self.chunks]
            )
        except ValueError as exc:
            raise ValueError(
                "The PDF text is too short or unsuitable for indexing. "
                "Try a PDF containing more readable text."
            ) from exc

        self.source_name = source_name or "uploaded.pdf"
        return {
            "filename": self.source_name,
            "pages_with_text": len(self.pages),
            "chunks_indexed": len(self.chunks),
        }

    def retrieve(self, question: str, top_k: int = 3) -> list[dict[str, Any]]:
        """Return the most similar document chunks for a question."""
        if self.vectorizer is None or self.matrix is None or not self.chunks:
            raise RuntimeError("Upload a PDF and build the knowledge base first.")
        if not question.strip():
            return []

        query_vector = self.vectorizer.transform([question.strip()])
        scores = cosine_similarity(query_vector, self.matrix).ravel()
        ranked_indices = scores.argsort()[::-1][: max(1, top_k)]
        results = []
        for idx in ranked_indices:
            score = float(scores[idx])
            if score <= 0:
                continue
            result = dict(self.chunks[int(idx)])
            result["score"] = score
            results.append(result)
        return results

    def answer(self, question: str, top_k: int = 3) -> dict[str, Any]:
        """Retrieve relevant text, then ask FLAN-T5 to answer only from that text."""
        question = question.strip()
        if not question:
            raise ValueError("Please enter a question.")

        sources = self.retrieve(question, top_k=top_k)
        if not sources:
            return {
                "answer": "I couldn't find relevant information for that question in this PDF.",
                "sources": [],
            }

        context = "\n\n".join(
            f"[PDF page {item['page']}] {item['text']}" for item in sources
        )
        prompt = (
            "Answer the question using only the context below. "
            "If the context does not contain the answer, say: "
            "I could not find that information in the PDF. "
            "Keep the answer clear and concise.\n\n"
            f"Context:\n{context}\n\n"
            f"Question: {question}\nAnswer:"
        )

        tokenizer, model, device = load_generator(self.model_name)
        encoded = tokenizer(
            prompt,
            return_tensors="pt",
            truncation=True,
            max_length=512,
        )
        encoded = {key: value.to(device) for key, value in encoded.items()}

        import torch

        with torch.inference_mode():
            output_ids = model.generate(
                **encoded,
                max_new_tokens=128,
                do_sample=False,
                num_beams=2,
                repetition_penalty=1.1,
            )
        answer_text = tokenizer.decode(output_ids[0], skip_special_tokens=True).strip()
        if not answer_text:
            answer_text = "I couldn't generate an answer. Try asking the question another way."

        return {"answer": answer_text, "sources": sources}
